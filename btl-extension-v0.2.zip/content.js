// content.js — injected on https://ps.btl.gov.il/*
//
// What it does:
//   1. Watches for a logged-in session (the portal stores its JWT in
//      sessionStorage.token after you log in — see API.md §3).
//   2. When logged in, drops a floating "show dashboard" button onto the page.
//   3. On click, reuses your LIVE session (the token + the cookies the browser
//      already holds) to call the portal's READ-ONLY JSON endpoints, exactly like
//      the portal's own app does — no password, no login, nothing stored.
//   4. Hands the fetched data to the service worker, which opens the dashboard.
//
// READ-ONLY: every endpoint below is one of the inquiry ("Berur"/list/GET) calls
// from the scraper's allowlist (src/api.js). No payments, edits, or submissions.

(() => {
  'use strict';

  const BTN_ID = 'btl-ext-dashboard-btn';
  const ORIGIN = 'https://ps.btl.gov.il';

  // Mirror of src/api.js ALLOWED_ENDPOINTS + src/branches.js (read-only).
  // `summary` is not here — it's already in sessionStorage.user (the login response).
  const ENDPOINTS = [
    { key: 'mevutach',      method: 'POST', path: 'api/MevutachApi/BerurMevutach' },
    { key: 'chovotGalash',  method: 'POST', path: 'api/ChovotApi/ChovotGalash' },
    { key: 'chovotGimlaot', method: 'POST', path: 'api/ChovotApi/ChovotGimlaot' },
    { key: 'galash',        method: 'POST', path: 'api/GalashApi/BerurGalash' },
    { key: 'miluim',        method: 'POST', path: 'api/MiluimApi/BerurMiluim' },
    { key: 'mismachim',     method: 'GET',  path: 'api/MismachimApi/Mismachim' },
    { key: 'pniyot',        method: 'GET',  path: 'api/PersonalApi/PniyotKodmot' },
    { key: 'letters',       method: 'POST', path: 'api/MichtavimApi/MichtavimList', query: 'prtcl=false' },
  ];

  function getToken() {
    try { const t = sessionStorage.getItem('token'); if (t) return t; } catch (_) {}
    try { const t = localStorage.getItem('token'); if (t) return t; } catch (_) {}
    return null;
  }

  function getSummary() {
    for (const store of [sessionStorage, localStorage]) {
      try {
        const raw = store.getItem('user');
        if (raw) return JSON.parse(raw);
      } catch (_) {}
    }
    return null;
  }

  async function callOne(token, ep) {
    const url = ORIGIN + '/' + ep.path + (ep.query ? '?' + ep.query : '');
    const headers = {
      'Authorization': token,            // raw JWT, no "Bearer " prefix (see API.md §3)
      'X-TS-AJAX-Request': 'true',
      'Accept': 'application/json, text/plain, */*',
    };
    const init = { method: ep.method, headers, credentials: 'include' };
    if (ep.method !== 'GET') {
      headers['Content-Type'] = 'application/json;charset=UTF-8';
      init.body = '{}';
    }
    const res = await fetch(url, init);
    const text = await res.text();
    if (!res.ok) throw new Error(res.status + ': ' + (text || '').slice(0, 120));
    try { return text ? JSON.parse(text) : null; } catch (_) { return null; }
  }

  function setBtn(btn, text, busy) {
    btn.textContent = text;
    btn.disabled = !!busy;
    btn.style.opacity = busy ? '0.75' : '1';
    btn.style.cursor = busy ? 'default' : 'pointer';
  }

  // True only while this content script is still connected to a live extension.
  // After the extension is reloaded/updated, content scripts already injected in
  // open tabs are orphaned and chrome.runtime (and .id) go away.
  function extensionAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }

  const REFRESH_MSG = 'התוסף נטען מחדש. רעננו את הדף (⌘R / Ctrl+R) ונסו שוב.';

  async function run(btn) {
    if (!extensionAlive()) { alert(REFRESH_MSG); return; }

    const token = getToken();
    if (!token) {
      alert('לא נמצאה התחברות פעילה לאזור האישי. התחברו לאתר ביטוח לאומי ונסו שוב.');
      return;
    }

    setBtn(btn, '⏳ טוען נתונים…', true);

    const data = { summary: getSummary() };
    const status = [{ name: 'summary', ok: !!data.summary, error: data.summary ? '' : 'לא נמצא ב-session' }];

    for (const ep of ENDPOINTS) {
      try {
        data[ep.key] = await callOne(token, ep);
        status.push({ name: ep.key, ok: true });
      } catch (e) {
        data[ep.key] = null;
        status.push({ name: ep.key, ok: false, error: String((e && e.message) || e) });
      }
    }

    const meta = { at: Date.now(), status };

    try {
      const resp = await chrome.runtime.sendMessage({ type: 'BTL_DATA', data, meta });
      if (resp && resp.ok === false) throw new Error(resp.error || 'unknown');
      setBtn(btn, '✓ הדשבורד נפתח', false);
      setTimeout(() => setBtn(btn, '📊 הצג את לוח המצב שלי', false), 2500);
    } catch (e) {
      const msg = String((e && e.message) || e);
      if (!extensionAlive() || /context invalidated|message port|receiving end/i.test(msg)) {
        alert(REFRESH_MSG);
      } else {
        alert('שגיאה בפתיחת הדשבורד: ' + msg.slice(0, 200));
      }
      setBtn(btn, '📊 הצג את לוח המצב שלי', false);
    }
  }

  function injectButton() {
    if (document.getElementById(BTN_ID)) return;
    if (!document.body) return;

    const btn = document.createElement('button');
    btn.id = BTN_ID;
    btn.type = 'button';
    btn.textContent = '📊 הצג את לוח המצב שלי';
    Object.assign(btn.style, {
      position: 'fixed',
      insetInlineEnd: '20px',
      bottom: '20px',
      zIndex: '2147483647',
      fontFamily: "'Assistant', Arial, sans-serif",
      fontSize: '15px',
      fontWeight: '600',
      color: '#fff',
      background: 'linear-gradient(135deg,#16b89a,#0f8f78)',
      border: 'none',
      borderRadius: '999px',
      padding: '13px 22px',
      boxShadow: '0 10px 26px -10px rgba(15,143,120,.85)',
      cursor: 'pointer',
      direction: 'rtl',
    });
    btn.addEventListener('click', () => run(btn));
    document.body.appendChild(btn);
  }

  function removeButton() {
    const b = document.getElementById(BTN_ID);
    if (b) b.remove();
  }

  // The portal is a single-page app, so login happens after the initial page load
  // (no full navigation). Poll for the session token and show/hide accordingly.
  setInterval(() => {
    if (getToken()) injectButton();
    else removeButton();
  }, 2500);
})();
