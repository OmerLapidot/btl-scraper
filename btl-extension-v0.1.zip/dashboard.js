// dashboard.js — renders the dashboard from the data the content script fetched.
//
// Reads chrome.storage.session (in-memory only) and builds a read-only view of
// debts, miluim, letters and previous inquiries. Defensive throughout: any missing
// or differently-shaped section degrades gracefully instead of throwing.

// ---------- formatting helpers ----------
const nf = new Intl.NumberFormat('en-US');
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = (n) => `<span class="num" dir="ltr">${nf.format(Math.round(Number(n) || 0))}</span>`;
const toNum = (v) => Number(String(v == null ? '' : v).replace(/[^\d.-]/g, '')) || 0;
const dmy = (s) => {
  const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || '');
  if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`;
  return String(s || '');
};
const toTime = (s) => {
  const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(s || '');
  if (m) return Date.UTC(+m[3], +m[2] - 1, +m[1]);
  const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || '');
  if (iso) return Date.UTC(+iso[1], +iso[2] - 1, +iso[3]);
  return 0;
};

// ---------- model ----------
function buildModel(data) {
  const summary = data.summary || {};

  // Debts (logic mirrors src/dashboard.js).
  const niHealth = data.chovotGalash || {};
  const benefits = data.chovotGimlaot || {};
  const collection = (data.galash || {}).Info || {};
  const gimlaotRows = (((benefits.Info || {}).ChovotGimlaotNew || {}).ChovotGimlaotNewTbl) || [];
  const gimlaotTotal = gimlaotRows.reduce((s, r) => s + (Number(r.YtratChovDec) || 0), 0);
  const klali = collection.klaliTab || {};
  const daf = collection.dafCheshbonTab || {};
  const debts = {
    niHealthClear: niHealth.InitialMessageType === 'Success',
    niHealthMsg: niHealth.InitialMessage || '',
    gimlaotTotal,
    inArrears: !!((klali.mufar || {}).isMufar),
    balanceDue: !!daf.YtrtChovExst,
    credit: (klali.zchut && klali.zchut.Tpl && klali.zchut.Tpl.schum) || null,
    status: (klali.maamadot || []).map((m) => m.Text).join(' ').replace(/\.$/, ''),
  };
  debts.hasMaterialDebt = !debts.niHealthClear || debts.inArrears || debts.balanceDue || gimlaotTotal > 50;

  // Miluim (raw — the rich reconciliation report is a later addition).
  const mInfo = (data.miluim || {}).Info || {};
  const t40 = mInfo.TabTosefet40Ahuz || {};
  const personalClaims = ((mInfo.TabTviotIshiyot || {}).TviotTbl || []).length;
  const employerClaims = ((mInfo.TabTviotMaasik || {}).TviotMaasikTbl || []).length;
  const miluim = {
    total40: toNum(t40.TashlumKolel),
    paid40: !!t40.ButzaTashlumLaMaasik,
    paid40Note: t40.HodaatChn || '',
    personalClaims,
    employerClaims,
    ironSwords: !!mInfo.TkufatCharvotBarzelExists,
    paymentsTbl: (mInfo.TabTashlumim || {}).KaspitTbl || null,
    hasAny: !!Object.keys(mInfo).length,
  };

  // Letters list (date + subject; no PDF download in this version).
  const letters = ((data.letters || {}).Letters || []).map((l) => ({
    date: l.LetterDate,
    subject: l.BtlSubjectName,
    isNew: !!l.isNew,
  })).sort((a, b) => toTime(b.date) - toTime(a.date));

  // Previous inquiries / site activity.
  const inq = (data.pniyot || {}).Info || {};
  const actTab = inq.TabSherutIshiCalls || {};
  const actTbl = actTab.PniyotTbl || actTab.CallsTbl || Object.values(actTab).find((v) => v && v.Headers) || {};
  const activity = (actTbl.TplRows || actTbl.Rows || []).map((r) => ({ date: r[0], time: r[1], source: r[2], activity: r[3] }));

  const name = summary.name || '';
  return {
    name,
    first: name.split(' ')[0] || '',
    avatar: name.replace(/\s/g, '').slice(0, 2) || '👤',
    zehutLast4: String((summary.currentZehut || {}).P_teudat_zehut || '').slice(-4),
    debts, miluim, letters, activity,
  };
}

// ---------- render ----------
function moreBar(id, total, shown) {
  if (total <= shown) return '';
  return `<div class="more-bar"><button class="more-btn" id="${id}" aria-expanded="false"><span class="txt">הצג עוד (${total - shown})</span><span class="arr">▾</span></button></div>`;
}

function genericTable(tbl, hiddenFrom) {
  if (!tbl || !Array.isArray(tbl.Headers) || !tbl.Headers.length) return '';
  const rows = tbl.TplRows || tbl.Rows || [];
  if (!rows.length) return '';
  const head = tbl.Headers.map((h) => `<th>${esc(h)}</th>`).join('');
  const body = rows.map((r, i) => {
    const cells = (Array.isArray(r) ? r : Object.values(r)).map((c) => `<td>${esc(c)}</td>`).join('');
    return `<tr class="${i >= hiddenFrom ? 'hidden-row gen-extra' : ''}">${cells}</tr>`;
  }).join('');
  return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

function debtsSection(d) {
  const ok = !d.hasMaterialDebt;
  const chips = [
    `<div class="chip ${d.niHealthClear ? 'chip-ok' : 'chip-bad'}"><div class="chip-ico">${d.niHealthClear ? '✓' : '!'}</div><div><div class="lbl">דמי ביטוח ובריאות</div><div class="val">${d.niHealthClear ? 'אין חוב' : 'קיים חוב'}</div></div></div>`,
    `<div class="chip ${d.inArrears ? 'chip-bad' : 'chip-ok'}"><div class="chip-ico">${d.inArrears ? '!' : '🕊️'}</div><div><div class="lbl">סטטוס תשלומים</div><div class="val">${d.inArrears ? 'בפיגור' : 'לא בפיגור'}</div></div></div>`,
    d.credit ? `<div class="chip chip-credit"><div class="chip-ico">★</div><div><div class="lbl">יתרת גבייה</div><div class="val">${esc(d.credit)}</div></div></div>` : '',
    d.gimlaotTotal > 0 ? `<div class="chip chip-pending"><div class="chip-ico">⏳</div><div><div class="lbl">גמלאות</div><div class="val">${num(d.gimlaotTotal)} ₪ — בבדיקה</div></div></div>` : '',
  ].join('');

  return `<section class="sec">
    <div class="sec-head"><div class="sec-ico">💳</div><h2>חובות</h2></div>
    <div class="verdict${ok ? '' : ' warn'}">
      <div class="verdict-top">
        <div class="check-badge${ok ? '' : ' warn'}">${ok ? '✓' : '!'}</div>
        <div class="verdict-txt">
          <h3 class="${ok ? '' : 'warn'}">${ok ? 'אין חובות 🎉' : 'יש לבדוק חובות'}</h3>
          <p>${d.niHealthClear ? 'הכול מסודר — אין חוב פעיל בדמי ביטוח או בבריאות.' : esc(d.niHealthMsg || 'נמצא חוב פעיל — מומלץ לבדוק.')}</p>
          <span class="status-tag"><span>●</span> מעמד: ${esc(d.status) || '—'} · ${d.inArrears ? 'בפיגור' : 'לא בפיגור'}</span>
        </div>
      </div>
      <div class="chips">${chips}</div>
    </div>
  </section>`;
}

function miluimSection(m) {
  if (!m.hasAny) return '';
  const payTable = genericTable(m.paymentsTbl, 5);
  return `<section class="sec">
    <div class="sec-head"><div class="sec-ico">🎖️</div><h2>מילואים</h2></div>
    <div class="stats">
      <div class="stat accent"><div class="cap">➕ תוספת 40%</div><div class="big">${num(m.total40)} <span class="unit">₪</span></div>${m.paid40 ? '<span class="paid-ok">✓ שולמה</span>' : '<span class="paid-no">⏳ טרם שולמה</span>'}</div>
      <div class="stat"><div class="cap">📨 תביעות אישיות</div><div class="big">${num(m.personalClaims)}</div></div>
      <div class="stat"><div class="cap">🏢 תביעות מעסיק</div><div class="big">${num(m.employerClaims)}</div></div>
      <div class="stat"><div class="cap">🛡️ חרבות ברזל</div><div class="big" style="font-size:19px">${m.ironSwords ? 'כן' : '—'}</div></div>
    </div>
    ${m.paid40 && m.paid40Note ? `<div class="note40">✓ <span>${esc(m.paid40Note)}</span></div>` : ''}
    ${payTable ? `<div class="panel"><div class="panel-cap"><span>תשלומים</span></div>${payTable}${moreBar('genBtn', ((m.paymentsTbl.TplRows || m.paymentsTbl.Rows || []).length), 5)}</div>` : ''}
  </section>`;
}

function lettersSection(letters) {
  const LV = 8;
  const subjClass = (s) => s === 'גבייה' ? ' coll' : (s === 'מילואים' ? '' : ' neutral');
  const rows = letters.map((l, i) => `<tr class="${i >= LV ? 'hidden-row letters-extra' : ''}">
      <td class="n"><span class="num" dir="ltr">${esc(dmy(l.date))}</span></td>
      <td><span class="subj-pill${subjClass(l.subject)}">${esc(l.subject) || '—'}</span>${l.isNew ? '<span class="new-dot" title="חדש"></span>' : ''}</td>
    </tr>`).join('');
  return `<section class="sec">
    <div class="sec-head"><div class="sec-ico sky">✉️</div><h2>מכתבים מהביטוח הלאומי</h2></div>
    <div class="panel">
      <div class="panel-cap"><span>מכתבים</span><span class="c">${letters.length} מכתבים</span></div>
      ${letters.length ? `<table><thead><tr><th>תאריך</th><th>נושא</th></tr></thead><tbody>${rows}</tbody></table>${moreBar('lettersBtn', letters.length, LV)}` : '<div class="panel-empty">אין מכתבים להצגה.</div>'}
    </div>
  </section>`;
}

function activitySection(activity) {
  if (!activity.length) return '';
  const AV = 6;
  const rows = activity.map((a, i) => `<tr class="${i >= AV ? 'hidden-row activity-extra' : ''}">
      <td class="n"><span class="num" dir="ltr">${esc(a.date)}</span></td>
      <td class="n"><span class="num" dir="ltr">${esc(a.time)}</span></td>
      <td class="subj-cell">${esc(a.source)}</td>
      <td>${esc(a.activity)}</td>
    </tr>`).join('');
  return `<section class="sec">
    <div class="sec-head"><div class="sec-ico sky">🗂️</div><h2>פניות ופעילות קודמת</h2></div>
    <div class="panel">
      <div class="panel-cap"><span>פעילות באתר</span><span class="c">${activity.length} רשומות</span></div>
      <table><thead><tr><th>תאריך</th><th>שעה</th><th>מקור</th><th>פעילות</th></tr></thead><tbody>${rows}</tbody></table>
      ${moreBar('activityBtn', activity.length, AV)}
    </div>
  </section>`;
}

function fetchLog(meta) {
  const st = (meta && meta.status) || [];
  if (!st.length) return '';
  const items = st.map((s) => `<li><span class="${s.ok ? 'ok' : 'bad'}">${s.ok ? '✓' : '✗'}</span> <code>${esc(s.name)}</code>${s.ok ? '' : ` — <span class="bad">${esc(s.error || 'נכשל')}</span>`}</li>`).join('');
  const okCount = st.filter((s) => s.ok).length;
  return `<details class="fetchlog"><summary>סטטוס משיכת נתונים (${okCount}/${st.length})</summary><ul>${items}</ul></details>`;
}

function render(model, meta) {
  const now = new Date();
  const dateStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
  const h = now.getHours();
  const greet = h < 12 ? 'בוקר טוב' : h < 18 ? 'צהריים טובים' : 'ערב טוב';

  const html = `
  <header class="hdr">
    <div class="avatar">${esc(model.avatar)}</div>
    <div class="greet">
      <h1>${esc(greet)}${model.first ? ', ' : ''}<span class="nm">${esc(model.first)}</span> <span class="wave">👋</span></h1>
      <div class="sub"><span class="dot"></span>מצב נכון ל־<span class="num" dir="ltr">${esc(dateStr)}</span></div>
    </div>
  </header>
  ${debtsSection(model.debts)}
  ${miluimSection(model.miluim)}
  ${lettersSection(model.letters)}
  ${activitySection(model.activity)}
  <footer>
    <div class="fline">🔒 תצוגה בלבד · הנתונים נמשכו ישירות מהאזור האישי ונשארים בדפדפן שלך</div>
    ${model.zehutLast4 ? `<div>ת״ז ●●●●●${esc(model.zehutLast4)} · נכון ל־<span class="num" dir="ltr">${esc(dateStr)}</span></div>` : ''}
    ${fetchLog(meta)}
  </footer>`;

  document.getElementById('app').innerHTML = html;
  wireToggles();
}

function wireToggles() {
  const wire = (btnId, rowClass) => {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    const rows = document.querySelectorAll('.' + rowClass);
    const txt = btn.querySelector('.txt');
    const more = txt ? txt.textContent : '';
    let open = false;
    btn.addEventListener('click', () => {
      open = !open;
      rows.forEach((r) => r.classList.toggle('show', open));
      if (txt) txt.textContent = open ? 'הצג פחות' : more;
      btn.classList.toggle('open', open);
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  };
  wire('genBtn', 'gen-extra');
  wire('lettersBtn', 'letters-extra');
  wire('activityBtn', 'activity-extra');
}

function renderEmpty() {
  document.getElementById('app').innerHTML = `<div class="empty">
    <h2>אין נתונים להצגה 🤔</h2>
    <p>כדי לראות את לוח המצב:</p>
    <ol>
      <li>פתחו את <b>ps.btl.gov.il</b> והתחברו לאזור האישי.</li>
      <li>לחצו על הכפתור הירוק שמופיע בפינת המסך.</li>
    </ol>
  </div>`;
}

// ---------- boot ----------
(async () => {
  try {
    const { btlData, btlMeta } = await chrome.storage.session.get(['btlData', 'btlMeta']);
    if (!btlData) { renderEmpty(); return; }
    render(buildModel(btlData), btlMeta);
  } catch (e) {
    document.getElementById('app').innerHTML = `<div class="empty"><h2>שגיאה</h2><p>${esc((e && e.message) || e)}</p></div>`;
  }
})();
