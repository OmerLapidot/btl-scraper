# BTL Dashboard — Chrome extension (v0.1, test build)

A **read-only** browser extension that shows a clean Hebrew dashboard of your
Bituach Leumi (ביטוח לאומי) personal area — debts, miluim, letters, and past
inquiries.

## How it works (and why it's safe)

- It does **not** ask for, store, or transmit your password. You log into
  `ps.btl.gov.il` yourself, as usual.
- Once you're logged in, the extension reuses the session your browser already
  holds (the JWT the portal keeps in `sessionStorage`) to call the same
  **read-only** inquiry endpoints the portal's own app uses.
- The fetched data is kept **in memory only** (`chrome.storage.session`, wiped when
  you close the browser) and rendered into a local dashboard tab. **Nothing is sent
  to any server** — the only network calls are same-origin reads to `ps.btl.gov.il`.
- The endpoint list mirrors the scraper's read-only allowlist: no payments, edits,
  claim submissions, or uploads.

## Install (load unpacked — for testing)

1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode** (top-right).
3. Click **Load unpacked** and select this `extension/` folder.
4. Go to <https://ps.btl.gov.il> and log in.
5. A green **"📊 הצג את לוח המצב שלי"** button appears at the bottom corner —
   click it. The dashboard opens in a new tab.

## What's in this test build

- ✅ Live-session fetch of: insurance status, NI/health debt, benefits debt,
  collection ledger, miluim, sent documents, previous inquiries, letters list.
- ✅ Dashboard: debts verdict, miluim summary, letters, and activity.
- ✅ A "fetch status" expander at the bottom shows per-endpoint success/failure
  (handy if something needs debugging).

## Known limits (next iterations)

- Miluim shows a summary from the raw data; the full per-period reconciliation
  report (from the Node tool) isn't ported yet.
- Letter **PDFs** aren't downloaded — only the list (date + subject) is shown.
- No email and no scheduling — this is the on-demand, click-to-view version.

## Troubleshooting

- **No button appears:** make sure you're actually logged in (the personal area is
  visible), then wait ~2 seconds. The button polls for your session.
- **The dashboard says "no data" or an endpoint failed:** open the "fetch status"
  expander at the bottom of the dashboard, and check the service-worker console at
  `chrome://extensions` → this extension → *Inspect views: service worker*.
